package com.example.shubham11714294_customview;

import android.content.Context;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatButton;

public class custombtn extends AppCompatButton {
    public custombtn(Context context) {
        this(context, null);
    }

    public custombtn(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public custombtn(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
