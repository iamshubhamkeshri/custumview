package com.example.shubham11714294_customview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {

    private MyRadioButton acrbMale;
    private MyRadioButton acrbFemale;
    TextView result1,result2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_main );
        acrbFemale = findViewById(R.id.acrb_female);
        acrbMale = findViewById(R.id.acrb_male);
        CheckBox tick = findViewById(R.id.tick);
        CheckBox tick2 = findViewById(R.id.tick2);
        CheckBox tick3= findViewById(R.id.tick3);
        CheckBox tick4 = findViewById(R.id.tick4);

        tick.setOnCheckedChangeListener( this );
        tick2.setOnCheckedChangeListener( this );
        tick3.setOnCheckedChangeListener( this );
        tick4.setOnCheckedChangeListener( this );

        result1=findViewById ( R.id.result );
        result2=findViewById ( R.id.result );
    }

    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        //int id = buttonView.getId();

        Toast.makeText ( this, "value is " + isChecked, Toast.LENGTH_SHORT ).show ();

    }

    private void setListeners() {
        setRadiosListener();
    }

    private void setRadiosListener() {
        acrbFemale.setOwnOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                result1.setText ( "male" +isChecked);
            }
        });
        acrbMale.setOwnOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                result1.setText ( "Female"+isChecked );
            }
        });
    }
}
